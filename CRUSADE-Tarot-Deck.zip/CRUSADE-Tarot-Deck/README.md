# Binding of Isaac Tarot Cards
A Balatro mod that adds the official Tarot cards from The Binding of Isaac. <br/>
Requires [Malverk](https://github.com/Eremel/Malverk).

![Tarots1](https://github.com/user-attachments/assets/324fb28e-b441-4cbf-b16c-b905219d064a)
![Tarots2](https://github.com/user-attachments/assets/5a8daaa9-7478-4724-acea-53f6d1dfe181)

The art used does not belong to me. It is from the Tarot Set sold by Edmund McMillen and Nicalis.
